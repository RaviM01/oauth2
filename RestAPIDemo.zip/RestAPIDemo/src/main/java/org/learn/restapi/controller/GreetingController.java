package org.learn.restapi.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {
    @GetMapping("/messages")
    //@PreAuthorize("hasAuthority('SCOPE_message.read')")
    public String[] getMessages() {
        return new String[] {"Message 1", "Message 2", "Message 3"};
    }

    @PostMapping("/messages")
    //@PreAuthorize("hasAuthority('SCOPE_message.write')")
    public String[] updateMessages() {
        return new String[] {"Message 1", "Message 2", "Message 3"};
    }

}
