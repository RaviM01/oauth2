package com.example.authserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
